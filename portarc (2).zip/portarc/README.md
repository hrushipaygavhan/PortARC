# PORTARC — handheld prototype

A single self-contained HTML file. No build step, no dependencies, no server required.

## Running it

Open `index.html` in any modern browser. That's it.

To test on a phone on your own network:

    cd portarc
    python3 -m http.server 8080

Then visit `http://<your-computer-ip>:8080` from the phone.

To host it, drop `index.html` on any static host (Netlify, Vercel, GitHub Pages, S3).

## Controls

| Action | Keyboard | Touch |
|---|---|---|
| D-pad | Arrows / WASD | on-screen buttons |
| OK (A) | Enter / Space / Z | red button |
| Back (B) | Shift / X / Esc | yellow button |
| Power | P | key on right edge |
| Eject | E | tap the cartridge nub |
| Focus mode | F | button, top right |
| Pause | hold Back | hold yellow button |

Drag a cartridge into the top slot on desktop, or tap one on mobile.

## Games

- **Snake Master** — walls accumulate every 5th pickup and speed ramps with them.
- **Tetris Gangster** — 7-bag randomiser, wall kicks, ghost piece, hold slot (yellow), hard drop (up), rotate (OK).
- **Dimond** — turn-based dungeon crawl. Collect every gem to open the portal. Wraiths move on alternating turns; OK waits a turn to bait them.

High scores and system settings persist to `localStorage`.

## Notes on the build

- Everything is inline: SVG cartridge art, synthesised audio (Web Audio, no files), and all three games on one `<canvas>`.
- The only external request is Google Fonts (Chakra Petch, Poppins, Press Start 2P). Remove the `<link>` in `<head>` to run fully offline — the CSS falls back to system sans-serif.
- Haptics: Android uses `navigator.vibrate()`. iOS has no Vibration API, so each control carries an invisible native `<input type="checkbox" switch>` whose direct tap fires the Taptic Engine. That only works on a real tap, not from script.
- Screen is 267x270 CSS px, matching the original Figma frame. Device body is 339x513. The cartridge slot position is driven by the `--slotL` / `--slotW` variables on `#device`.
